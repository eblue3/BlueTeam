
/******************************************************************************\
*       This is a part of the Microsoft Source Code Samples. 
*       Copyright 1993 - 2000 Microsoft Corporation.
*       All rights reserved. 
*       This source code is only intended as a supplement to 
*       Microsoft Development Tools and/or WinHelp documentation.
*       See these sources for detailed information regarding the 
*       Microsoft samples programs.
\******************************************************************************/


#define IDM_BOX     101
#define IDM_BLOCK   102
#define IDM_RETAIN  103
#define IDM_ABOUT   104

#define IDS_APPNAME     1001
#define IDS_NOMEM       1002

BOOL DemoInit(HANDLE);
LRESULT APIENTRY DemoWndProc(HWND, UINT, UINT, LONG);
BOOL APIENTRY About(HWND, UINT, UINT, LONG);
